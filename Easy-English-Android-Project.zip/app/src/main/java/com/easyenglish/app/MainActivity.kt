package com.easyenglish.app

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Navy = Color(0xFF0F172A)
private val Card = Color(0xFF1E293B)
private val Blue = Color(0xFF3B82F6)

class MainActivity : ComponentActivity() {
    private var speaker: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speaker = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) speaker?.language = Locale.US
        }
        setContent { EasyEnglishApp { phrase -> speaker?.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "ee") } }
    }
    override fun onDestroy() { speaker?.shutdown(); super.onDestroy() }
}

@Composable
fun EasyEnglishApp(speak: (String) -> Unit) {
    var tab by remember { mutableStateOf("الرئيسية") }
    var query by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    val words = listOf("Book" to "كتاب", "School" to "مدرسة", "Beautiful" to "جميل", "Improve" to "يطوّر", "Remember" to "يتذكّر")
    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Card, primary = Blue, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Navy, bottomBar = {
            NavigationBar(containerColor = Card) {
                listOf("الرئيسية", "الكلمات", "القواعد", "التحديات").forEach {
                    NavigationBarItem(selected = tab == it, onClick = { tab = it },
                        icon = {}, label = { Text(it) })
                }
            }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item {
                    Text("Easy English", color = Color.White, fontSize = 28.sp)
                    Text("اتعلم الإنجليزي خطوة بخطوة", color = Color.LightGray)
                }
                when (tab) {
                    "الرئيسية" -> {
                        item { Panel("أهلاً بيك 👋", "ابدأ رحلتك من الصفر إلى الاحتراف.") }
                        item { Panel("خطة اليوم", "راجع 5 كلمات، وتعلّم قاعدة، ثم اختبر نفسك.") }
                        item { Panel("مميزات التطبيق", "كلمات • قواعد • استماع • ألعاب • امتحانات") }
                    }
                    "الكلمات" -> {
                        item { OutlinedTextField(query, { query = it }, label = { Text("ابحث عن كلمة") }, modifier = Modifier.fillMaxWidth()) }
                        items(words.size) { i ->
                            val (en, ar) = words[i]
                            if (query.isBlank() || en.contains(query, true) || ar.contains(query)) {
                                Panel("$en — $ar", "اضغط للاستماع إلى النطق") {
                                    Button(onClick = { speak(en) }) { Text("استمع 🔊") }
                                }
                            }
                        }
                    }
                    "القواعد" -> {
                        item { Panel("Present Simple", "نستخدمه للعادات والحقائق.\nI play football every day.\nأنا ألعب كرة القدم كل يوم.") }
                        item { Panel("Present Continuous", "نستخدمه لحدث يحدث الآن.\nI am studying now.\nأنا أذاكر الآن.") }
                        item { Panel("ملاحظة", "هذه بداية تجريبية لقسم القواعد، وسيُستكمل المنهج التفصيلي في التطوير.") }
                    }
                    "التحديات" -> {
                        item { Panel("اختبار الكلمات", "المحتوى: Book, School, Beautiful") }
                        item { Text("What does Book mean?", color = Color.White, fontSize = 20.sp) }
                        item {
                            listOf("قلم", "كتاب", "باب").forEach { option ->
                                Button(onClick = { answer = if (option == "كتاب") "إجابة صحيحة! ⭐" else "حاول مرة أخرى" },
                                    modifier = Modifier.fillMaxWidth()) { Text(option) }
                            }
                        }
                        item { Text(answer, color = Color.White) }
                        item { Panel("اختبار القواعد", "المحتوى: Present Simple و Present Continuous. ستُضاف اختبارات مخصصة لكل درس ومجموعة كلمات.") }
                    }
                }
            }
        }
    }
}

@Composable
fun Panel(title: String, body: String, extra: (@Composable () -> Unit)? = null) {
    Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Color.White, fontSize = 19.sp)
            Text(body, color = Color.LightGray)
            extra?.invoke()
        }
    }
}
